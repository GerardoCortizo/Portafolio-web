    const ref = firebase.storage().ref();
    const db = firebase.firestore();


const form = document.getElementById("form");
const container = document.getElementById("container");

let editing = false;
let id = "";
let link = "";

const actualizar = (id, proyectoActualizado) =>
  db.collection("Proyectos").doc(id).update(proyectoActualizado);

const save = (nombre, cate, descr, url) =>{
  db.collection("Proyectos").doc().set({
    nombre,
    cate,
    descr,
    url
  });
}

async function uploadImage() {
  const file = document.querySelector("#imagen").files[0];
  if (!file){
        return "../img/error.png";
  } else{
    const name = new Date() + "-" + file.name;
    const metadata = {
      contentType: file.type
    }
    const snapshot = await ref.child(name).put(file,metadata)
    const url = await snapshot.ref.getDownloadURL();
    return url;
  }
};

  
    

const onGetProyectos = (callback) =>
  db.collection("Proyectos").onSnapshot(callback);

const getProyecto = (id) => db.collection("Proyectos").doc(id).get();

const deleteProyect = (id) => db.collection("Proyectos").doc(id).delete();



window.addEventListener("DOMContentLoaded", async (e) => {
  onGetProyectos((querySnapshot) => {
    container.innerHTML = "";

    querySnapshot.forEach((doc) => {
      const elemento = doc.data();
      elemento.id = doc.id;

      container.innerHTML += `<div class="card-body">
      <h4 class="card-title">${elemento.nombre}</h4>
      <p class="card-text">Categoría: ${elemento.cate}.</p>
      <p class="card-text">${elemento.descr}.</p>
      <button class="btn btnEditar" data-id="${elemento.id}">Editar</button>
      <button class="btn btnBorrar" data-id="${elemento.id}">Borrar</button>
    </div>
    `;

      const borrar = document.querySelectorAll(".btnBorrar");

      borrar.forEach((btnBorrar) => {
        btnBorrar.addEventListener("click", async (e) => {
          await deleteProyect(e.target.dataset.id);
        });
      });

      const editar = document.querySelectorAll(".btnEditar");

      editar.forEach((btnEditar) => {
        btnEditar.addEventListener("click", async (f) => {
          const docu = await getProyecto(f.target.dataset.id);
          editing = true;
          id = docu.id;

          form["newName"].value = docu.data().nombre;
          form["newDescr"].value = docu.data().descr;
          document.getElementById("newCategoria").value = docu.data().cate;
          form["new"].innerText = "Actualizar";
          link = docu.data().url;
        });
      });
    });
  });
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const nombre = form["newName"].value;
  const descr = form["newDescr"].value;
  const cate = document.getElementById("newCategoria").value;

  if (!editing) {
    link = await uploadImage();
    console.log(link);
    save(nombre, cate, descr, link);
    link = "";
  } else {
        if (document.querySelector("#imagen").files[0]) {
          link = await uploadImage();
          actualizar(id, {
            nombre: nombre,
            cate: cate,
            descr: descr,
            url: link
          })
        }
        else{
          await actualizar(id, {
            nombre: nombre,
            cate: cate,
            descr: descr
          });
        }
      }

  form["new"].innerText = "Agregar";


  form.reset();
  editing = false;
  id = "";
});
