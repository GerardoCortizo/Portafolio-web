//Registro
const signupForm = document.querySelector('#signupForm');

signupForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const signupEmail = document.getElementById('signup-email').value;
    const signupPwd = document.getElementById('signup-pwd').value;

    firebase.auth()
        .createUserWithEmailAndPassword(signupEmail, signupPwd)
        .then(userCredential => {
            signupForm.reset();

            $('#signupModal').modal('hide')
            console.log('signUp')
        });

});

//Ingreso

const signinForm = document.querySelector('#signinForm');

signinForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const signinEmail = document.getElementById('signin-email').value;
    const signinPwd = document.getElementById('signin-pwd').value;
    firebase.auth()
    .signInWithEmailAndPassword(signinEmail, signinPwd)
    .then(userCredential => {
        signinForm.reset();
        $('#signinModal').modal('hide');
    }).catch(function(error) {alert("Correo o contraseña no válidos")});
    
    
});

const logout = document.querySelector('#logout');

logout.addEventListener('click', e => {
    e.preventDefault();
    auth.signOut().then(() => {
        console.log('sign-out');
    })
});

auth.onAuthStateChanged(user => {
    if (user){
        document.getElementById('signupLink').classList.add("hide");
        document.getElementById('signinLink').classList.add("hide");
        document.getElementById('logout').classList.remove("hide");
        if (user.uid === "lCTTtm15pIXo6lHyIerK8Zel5er1"){
            document.getElementById('CRUD').classList.remove("hide");
        }
    } else{
        document.getElementById('logout').classList.add("hide");
        document.getElementById('signupLink').classList.remove("hide");
        document.getElementById('signinLink').classList.remove("hide");
        document.getElementById('CRUD').classList.add("hide");
    }
});

window.addEventListener("DOMContentLoaded", async (e) => {
    let user = firebase.auth().currentUser;
    if (user){
        if (user.uid === "lCTTtm15pIXo6lHyIerK8Zel5er1"){
            document.getElementById('CRUD').classList.remove("hide");
            console.log('admin wiii')
        } else {
            document.getElementById('CRUD').classList.add("hide");
            console.log('no admin :(')

        }
    }
});
