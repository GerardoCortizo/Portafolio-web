const db = firebase.firestore();
let todos = document.getElementById("todos");
let termo = document.getElementById("termo");
let bash = document.getElementById("bash");
let estructura = document.getElementById("estructura");
const proyectos = document.getElementById("proyectos");

const onGetProyectos = (callback) =>
  db.collection("Proyectos").onSnapshot(callback);

todos.onclick = function () {
  let all = document.getElementsByClassName("todos");
  for (let i = 0; i < all.length; i++) {
    all[i].classList.remove("hide");
    console.log(all[i].classList);
  }
};

termo.onclick = function () {
  let all = document.getElementsByClassName("todos");
  for (let i = 0; i < all.length; i++) {
    all[i].classList.add("hide");
  }
  let term = document.getElementsByClassName("Termodinamica");
  for (let i = 0; i < term.length; i++) {
    console.log(term[i].classList);
    term[i].classList.remove("hide");
  }
};

bash.onclick = function () {
  let all = document.getElementsByClassName("todos");
  for (let i = 0; i < all.length; i++) {
    all[i].classList.add("hide");
  }
  let ba = document.getElementsByClassName("Bash");
  for (let i = 0; i < ba.length; i++) {
    ba[i].classList.remove("hide");
  }
};

estructura.onclick = function () {
  let all = document.getElementsByClassName("todos");
  for (let i = 0; i < all.length; i++) {
    all[i].classList.add("hide");
    console.log(all[i].classList);
  }
  let estr = document.getElementsByClassName("Estructura");
  for (let i = 0; i < estr.length; i++) {
    estr[i].classList.remove("hide");
    console.log(estr[i].classList);
  }
};


window.addEventListener("DOMContentLoaded", async (e) => {
  onGetProyectos((querySnapshot) => {
    proyectos.innerHTML = "";

    querySnapshot.forEach((doc) => {
      const elemento = doc.data();
      elemento.id = doc.id;

      proyectos.innerHTML += `<div class="col-8 container ${elemento.cate} todos">
                                <div class="caja">
                                  <a href="Portfolio.html" class="portfolio">
                                    <img
                                      src="${elemento.url}" 
                                      alt="error"
                                      class="h-100 d-inline-block img-fluid"
                                    />
                                    ${elemento.nombre}
                                  </a>
                                </div>
                              </div>`;
      
                              //elemento.descr para los detalles
    });
  });

});